package com.example.weather_app.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class WeatherApplicationTest {

    private final ComfortIndexService service = new ComfortIndexService();

    @Test
    void idealConditionsProduceHighScore() {
        // temp = 22C (ideal), humidity = 45% (ideal), calm wind, clear sky
        double score = service.calculateComfortScore(22.0, 45, 0.0, 0);
        assertEquals(100.0, score, 0.01);
    }
    @Test
    void extremeHeatProducesLowScore() {
        double score = service.calculateComfortScore(45.0, 95, 12.0, 100);
        assertEquals(true, score < 30.0);
    }
    @Test
    void extremeHeatAndHumidityProduceLowScore() {
        double score = service.calculateComfortScore(42.0, 95, 10.0, 100);
        assertTrue(score < 20.0, "Expected a low comfort score for extreme heat/humidity, got " + score);
    }

    @Test
    void scoreIsNeverNegative() {
        double score = service.calculateComfortScore(-30.0, 100, 40.0, 100);
        assertTrue(score >= 0.0);
    }

    @Test
    void scoreIsNeverAboveHundred() {
        double score = service.calculateComfortScore(22.0, 45, -5.0, -5);
        assertTrue(score <= 100.0);
    }

    @Test
    void moderateDeviationProducesMidRangeScore() {
        // A pleasant but not perfect day: 26C, 55% humidity, light breeze, partly cloudy
        double score = service.calculateComfortScore(26.0, 55, 3.0, 30);
        assertTrue(score > 60.0 && score < 95.0, "Expected mid-to-high comfort score, got " + score);
    }
}
