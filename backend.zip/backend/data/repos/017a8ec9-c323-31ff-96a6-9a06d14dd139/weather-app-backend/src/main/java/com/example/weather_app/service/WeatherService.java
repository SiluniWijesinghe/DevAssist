package com.example.weather_app.service;

import com.example.weather_app.config.CacheConfig;
import com.example.weather_app.model.dto.WeatherApiResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

@Service
public class WeatherService {

    private static final Logger log =
            LoggerFactory.getLogger(WeatherService.class);

    private final RestClient restClient;
    private final CacheManager cacheManager;

    @Value("${openweathermap.api-key}")
    private String apiKey;

    @Value("${openweathermap.base-url:https://api.openweathermap.org/data/2.5/weather}")
    private String baseUrl;

    private final Map<Long, String> lastLookupStatus =
            new ConcurrentHashMap<>();

    public WeatherService(
            RestClient.Builder restClientBuilder,
            CacheManager cacheManager) {

        this.restClient = restClientBuilder.build();
        this.cacheManager = cacheManager;
    }

    public WeatherApiResponse getWeatherForCity(Long cityId) {

        Cache cache = cacheManager.getCache(CacheConfig.WEATHER_CACHE);

        if (cache == null) {
            throw new IllegalStateException(
                    "Weather cache is not configured");
        }

        WeatherApiResponse cached =
                cache.get(cityId, WeatherApiResponse.class);

        if (cached != null) {
            lastLookupStatus.put(cityId, "HIT");
            log.debug("Cache HIT for city {}", cityId);
            return cached;
        }

        lastLookupStatus.put(cityId, "MISS");
        log.debug("Cache MISS for city {} — calling OpenWeatherMap", cityId);

        WeatherApiResponse response =
                fetchFromOpenWeatherMap(cityId);

        cache.put(cityId, response);

        return response;
    }

    private WeatherApiResponse fetchFromOpenWeatherMap(Long cityId) {

        String url = baseUrl
                + "?id=" + cityId
                + "&appid=" + apiKey
                + "&units=metric";

        try {
            return restClient.get()
                    .uri(url)
                    .retrieve()
                    .body(WeatherApiResponse.class);

        } catch (Exception ex) {
            log.error(
                    "Failed to fetch weather for city {}: {}",
                    cityId,
                    ex.getMessage());

            throw new WeatherFetchException(
                    "Unable to fetch weather for city id " + cityId,
                    ex);
        }
    }

    public Map<Long, String> getLastLookupStatus() {
        return lastLookupStatus;
    }

    public static class WeatherFetchException
            extends RuntimeException {

        public WeatherFetchException(
                String message,
                Throwable cause) {

            super(message, cause);
        }
    }
}