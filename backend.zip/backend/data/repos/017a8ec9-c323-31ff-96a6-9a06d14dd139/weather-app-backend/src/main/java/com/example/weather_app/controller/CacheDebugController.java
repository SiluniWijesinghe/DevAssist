package com.example.weather_app.controller;

import com.example.weather_app.config.CacheConfig;
import com.example.weather_app.service.WeatherService;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.stats.CacheStats;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.cache.caffeine.CaffeineCache;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.Map;


@RestController
@RequestMapping("/api/cache")
public class CacheDebugController {

    private final CacheManager cacheManager;
    private final WeatherService weatherService;

    public CacheDebugController(CacheManager cacheManager,WeatherService weatherService) {
        this.cacheManager = cacheManager;
        this.weatherService = weatherService;
    }

    @GetMapping("/status")
    public Map<String, Object> getCacheStatus() {
        Map<String, Object> response = new LinkedHashMap<>();


        response.put("lastLookupByCity", weatherService.getLastLookupStatus());

        CaffeineCache springCache = (CaffeineCache) cacheManager.getCache(CacheConfig.WEATHER_CACHE);
        if (springCache != null) {
            Cache<Object, Object> nativeCache = springCache.getNativeCache();
            CacheStats stats = nativeCache.stats();

            Map<String, Object> aggregate = new LinkedHashMap<>();
            aggregate.put("hitCount", stats.hitCount());
            aggregate.put("missCount", stats.missCount());
            aggregate.put("hitRate", stats.hitRate());
            aggregate.put("entriesInCache", nativeCache.estimatedSize());
            response.put("aggregateStats", aggregate);
        }

        return response;
    }
}
