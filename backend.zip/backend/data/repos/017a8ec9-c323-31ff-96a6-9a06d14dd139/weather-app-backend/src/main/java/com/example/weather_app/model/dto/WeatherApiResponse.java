package com.example.weather_app.model.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.io.Serializable;
import java.util.List;


@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class WeatherApiResponse implements Serializable {

    private Long id;
    private String name;
    private List<WeatherInfo> weather;
    private Main main;
    private Wind wind;
    private Clouds clouds;
    private Long visibility;
    private Long dt;


    @JsonIgnoreProperties(ignoreUnknown = true)
    @Data
    public static class WeatherInfo implements Serializable {
        private String main;
        private String description;
        private String icon;

    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @Data
    public static class Main implements Serializable {
        private Double temp;
        private Double feelsLike;
        private Double tempMin;
        private Double tempMax;
        private Integer pressure;
        private Integer humidity;

    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @Data
    public static class Wind implements Serializable {
        private Double speed;
        private Integer deg;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @Data
    public static class Clouds implements Serializable {
        private Integer all;

    }
}
