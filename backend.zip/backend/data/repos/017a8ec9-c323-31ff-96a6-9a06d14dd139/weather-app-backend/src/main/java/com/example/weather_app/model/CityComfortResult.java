package com.example.weather_app.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CityComfortResult {

    private Long cityId;
    private String cityName;
    private String countryCode;
    private String weatherDescription;
    private double temperatureCelsius;
    private int humidity;
    private double windSpeed;
    private int cloudiness;
    private int pressure;
    private double comfortScore;
    private int rank;

}
