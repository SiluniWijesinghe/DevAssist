package com.example.weather_app.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.example.weather_app.model.City;
import com.example.weather_app.model.CityListResponse;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;

@Service
public class CityService {

    private static final Logger log = LoggerFactory.getLogger(CityService.class);

    private final ObjectMapper objectMapper;
    private List<City> cities = Collections.emptyList();

    public CityService(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @PostConstruct
    public void loadCities() {
        try (InputStream is = new ClassPathResource("cities.json").getInputStream()) {
            CityListResponse response = objectMapper.readValue(is, CityListResponse.class);
            cities = response.getList();
            log.info("Loaded {} cities from cities.json", cities.size());
        } catch (IOException e) {
            throw new IllegalStateException("Could not load cities.json from classpath", e);
        }
    }

    public List<City> getCities() {
        return cities;
    }
}