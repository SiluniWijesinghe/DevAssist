package com.example.weather_app.service;

import org.springframework.stereotype.Service;

@Service
public class ComfortIndexService {

    // Ideal Values
    private static final double IDEAL_TEMP_C = 22.0;
    private static final double IDEAL_HUMIDITY_PCT = 45.0;
    private static final double IDEAL_PRESSURE_HPA = 1013;

    // Penalty rate
    private static final double TEMP_PENALTY_PER_DEGREE = 4.0;
    private static final double HUMIDITY_PENALTY_PER_PERCENT = 1.2;
    private static final double WIND_PENALTY_PER_MPS = 8.0;
    private static final double CLOUD_PENALTY_PER_PERCENT = 0.4;
    private static final double PRESSURE_PENALTY_PER_HPA = 0.1;

    //relative importance
    private static final double WEIGHT_TEMP = 0.40;
    private static final double WEIGHT_HUMIDITY = 0.30;
    private static final double WEIGHT_WIND = 0.20;
    private static final double WEIGHT_CLOUD = 0.05;
    private static final double WEIGHT_PRESSURE = 0.05;

    public double calculateComfortScore(double temperatureCelsius, int humidityPct,
                                         double windSpeedMps, int cloudinessPct, int pressureHPa) {
        double tempScore = clamp(100 - Math.abs(temperatureCelsius - IDEAL_TEMP_C) * TEMP_PENALTY_PER_DEGREE);
        double humidityScore = clamp(100 - Math.abs(humidityPct - IDEAL_HUMIDITY_PCT) * HUMIDITY_PENALTY_PER_PERCENT);
        double pressureScore = clamp(100 - Math.abs(pressureHPa - IDEAL_PRESSURE_HPA) * PRESSURE_PENALTY_PER_HPA);
        double windScore = clamp(100 - windSpeedMps * WIND_PENALTY_PER_MPS);
        double cloudScore = clamp(100 - cloudinessPct * CLOUD_PENALTY_PER_PERCENT);

        double comfort = (WEIGHT_TEMP * tempScore)
                + (WEIGHT_HUMIDITY * humidityScore)
                + (WEIGHT_WIND * windScore)
                + (WEIGHT_CLOUD * cloudScore)
                + (WEIGHT_PRESSURE * pressureScore)
                ;

        return roundToOneDecimal(clamp(comfort));
    }

    private double clamp(double value) {
        return Math.max(0.0, Math.min(100.0, value));
    }

    private double roundToOneDecimal(double value) {
        return Math.round(value * 10.0) / 10.0;
    }
}
