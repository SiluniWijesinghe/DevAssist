package com.example.weather_app.service;

import com.example.weather_app.model.City;
import com.example.weather_app.model.CityComfortResult;
import com.example.weather_app.model.dto.WeatherApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;


@Service
public class CityRankingService {

    private final CityService cityService;
    private final WeatherService weatherService;
    private final ComfortIndexService comfortIndexService;

    public CityRankingService(CityService cityService,
                              WeatherService weatherService,
                              ComfortIndexService comfortIndexService) {
        this.cityService = cityService;
        this.weatherService = weatherService;
        this.comfortIndexService = comfortIndexService;
    }

    public List<CityComfortResult> getRankedCities() {
        List<City> cities = cityService.getCities();
        List<CityComfortResult> results = new ArrayList<>();

        for (City city : cities) {
            try {
                WeatherApiResponse weather = weatherService.getWeatherForCity(city.getCityCode());
                results.add(toComfortResult(city, weather));
            } catch (com.example.weather_app.service.WeatherService.WeatherFetchException ex) {
                continue;
            }
        }

        results.sort(Comparator.comparingDouble(CityComfortResult::getComfortScore).reversed());

        int rank = 1;
        for (CityComfortResult result : results) {
            result.setRank(rank++);
        }

        return results;
    }

    private CityComfortResult toComfortResult(City city, WeatherApiResponse weather) {
        CityComfortResult result = new CityComfortResult();
        result.setCityId(city.getCityCode());
        result.setCityName(city.getCityName());
//        result.setCountryCode(city.getCountryCode());

        double temp = weather.getMain() != null && weather.getMain().getTemp() != null
                ? weather.getMain().getTemp() : 0.0;
        int humidity = weather.getMain() != null && weather.getMain().getHumidity() != null
                ? weather.getMain().getHumidity() : 0;
        double windSpeed = weather.getWind() != null && weather.getWind().getSpeed() != null
                ? weather.getWind().getSpeed() : 0.0;
        int cloudiness = weather.getClouds() != null && weather.getClouds().getAll() != null
                ? weather.getClouds().getAll() : 0;
        int pressure = weather.getMain() != null && weather.getMain().getPressure() != null
                ? weather.getMain().getPressure() : 0;
        String description = (weather.getWeather() != null && !weather.getWeather().isEmpty())
                ? weather.getWeather().get(0).getDescription() : "N/A";

        result.setTemperatureCelsius(temp);
        result.setHumidity(humidity);
        result.setWindSpeed(windSpeed);
        result.setCloudiness(cloudiness);
        result.setPressure(pressure);
        result.setWeatherDescription(description);

        double score = comfortIndexService.calculateComfortScore(temp, humidity, windSpeed, cloudiness,pressure);
        result.setComfortScore(score);

        return result;
    }
}
