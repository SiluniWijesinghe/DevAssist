package com.example.weather_app.controller;

import com.example.weather_app.model.CityComfortResult;
import com.example.weather_app.service.CityRankingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class WeatherController {

    private final CityRankingService cityRankingService;

    public WeatherController(CityRankingService cityRankingService) {
        this.cityRankingService = cityRankingService;
    }

    @GetMapping("/comfort-rankings")
    public List<CityComfortResult> getComfortRankings() {
        return cityRankingService.getRankedCities();
    }
}
