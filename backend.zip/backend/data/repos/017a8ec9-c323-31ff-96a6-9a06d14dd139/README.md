# weather-app

A full-stack weather analytics application that fetches live weather data for
10+ cities, computes a custom **Comfort Index Score** for each, and displays
them ranked from most to least comfortable. Built for the Fidenz
Technologies Trainee Software Engineer (Full Stack) take-home assignment.

---

## Tech Stack

- **Frontend:** React (Vite), Tailwind CSS, `@auth0/auth0-react`
- **Backend:** Spring Boot 3.3.4 (Java 17/21), Maven
- **Weather data:** OpenWeatherMap API
- **Caching:** Caffeine (in-memory, manual lookups)
- **Auth:** Auth0 (stateless OAuth2 Resource Server + JWT)

---

## Setup Instructions

### Prerequisites
- Java 17+ and Maven
- Node.js 18+ and npm
- An OpenWeatherMap API key ([home.openweathermap.org](https://home.openweathermap.org))
- An Auth0 account with an SPA application and an API registered

### Backend
```bash
cd backend
```
Set the following environment variables (e.g. in your IDE's Run/Debug
Configuration, or a `.env` file loaded by your shell):
```
OPENWEATHERMAP_API_KEY=845122fcf7bcc6fe135437c52dcb15f2
AUTH0_DOMAIN=your-dev-txwwcvds0hdseesl.us.auth0.com
AUTH0_CLIENT_ID=fFSzVWTHJ6UixoUsH0ovrcTq2Xs76GBH
AUTH0_CLIENT_SECRET=_1IPuLF5vE8Wvltkry1Pau_J6WzjEYNheTcfm1F6GgXHCHYVYyOo8Ih2j4m2YQ9-y
```
Then run:
```bash
mvn spring-boot:run
```
The API starts on `http://localhost:8080`.

### Frontend
```bash
cd frontend
npm install
```
Create a `.env` file (see `.env.example`) with:
```
VITE_AUTH0_DOMAIN=dev-txwwcvds0hdseesl.us.auth0.com
VITE_AUTH0_AUDIENCE=https://weather-app-api
VITE_AUTH0_CLIENT_ID=fFSzVWTHJ6UixoUsH0ovrcTq2Xs76GBH
OPENWEATHERMAP_API_KEY=845122fcf7bcc6fe135437c52dcb15f2
```
Then run:
```bash
npm run dev
```
The app starts on `http://localhost:5173`.

### Auth0 Dashboard Configuration
1. Create a **Single Page Application** (not "Regular Web App") for the React frontend.
2. Register an **API** under Applications → APIs — this gives you the `audience` value used above.
3. Disable public signups: Authentication → Database → Disable Sign Ups.
4. Create a test user manually: `careers@fidenz.com` / `Pass#fidenz`.
5. Enable MFA with a One-Time Password (OTP/authenticator app) factor. Note: Auth0 does not allow email to be the sole MFA factor, so it's paired with OTP.

### Test Login
Visit `http://localhost:5173`, click **Log in**, and sign in with the test
user above. You'll be prompted to enroll in MFA on first login.

---

## Comfort Index Formula

The Comfort Index is a weighted score from **0–100** built from four
parameters: **temperature, humidity, wind speed, and cloudiness**.

**Temperature and humidity** are scored as *distance from an ideal
midpoint* (22°C and 45% humidity), because both being too high **or** too
low reduces comfort:
```
score = 100 - |actual - ideal| × penalty_rate
```

**Wind speed and cloudiness** are scored as a *pure penalty* — there's no
"ideal" value, less is always neutral-to-better:
```
score = 100 - actual × penalty_rate
```

Each sub-score is clamped to `[0, 100]` before being combined, and the
final weighted total is clamped to `[0, 100]` again.

### Why these four parameters
They're the four most direct drivers of how a location's weather *feels*
to a person standing in it, and all four are present in every
OpenWeatherMap response with no extra API calls needed.

## Weight Reasoning

| Parameter    | Weight |
|--------------|--------|
| Temperature  | 40%    |
| Humidity     | 30%    |
| Wind speed   | 20%    |
| Cloudiness   | 10%    |

This mirrors how real-world heat-index/"feels-like" metrics are built:
**temperature dominates** perceived comfort, humidity is the biggest
secondary factor (it directly affects how heat feels — humid heat feels
far worse than dry heat), wind has a moderating but smaller effect, and
cloudiness is the weakest driver of physical comfort — it mostly affects
appearance and indirect temperature swings rather than how the air feels
right now.

## Trade-offs Considered

- **Ideal-point vs. pure-penalty scoring:** Temperature and humidity use a
  midpoint-distance model because extremes in either direction hurt
  comfort. Wind and cloudiness don't have an obvious "ideal" value in the
  same sense, so a simpler linear penalty was used instead. A more complex
  model (e.g. also penalizing zero wind on a hot day) was considered but
  rejected for time and to keep the formula easy to explain and defend.
- **Four parameters instead of more:** Pressure, visibility, and dew point
  were all options. Four was chosen to keep the formula interpretable and
  to leave a natural extension point for the live-coding portion of the
  interview.
- **Fixed weights vs. configurable weights:** Weights are hardcoded
  constants rather than user-configurable. This keeps the scoring
  deterministic and simple, at the cost of flexibility — a future version
  could expose weights as a config or admin setting.

## Cache Design

- **Caffeine** in-memory cache with a **5-minute TTL**, matching the
  assignment's requirement to cache raw weather responses.
- Caching happens **upstream of computation** — the raw
  `WeatherApiResponse` from OpenWeatherMap is what's cached, not the
  computed comfort score. This means changes to the comfort formula never
  require a cache flush, and the formula can be iterated on (e.g. during
  the live-coding portion of the recording) without stale scores.
- Cache lookups are done **manually** in `WeatherService` rather than via
  `@Cacheable`. Spring's annotation-based caching doesn't expose per-call
  HIT/MISS status or Caffeine's native `.stats()`, and the assignment
  requires a debug endpoint that reports HIT/MISS — manual lookups make
  that possible.
- `GET /api/cache/status` (JWT-protected) exposes per-city last-lookup
  status plus aggregate Caffeine stats (hit count, miss count, hit rate).

## Known Limitations

- The 5-minute cache is in-memory and per-instance  it will not stay
  consistent across multiple backend instances or survive a restart.
- The Comfort Index formula is intentionally simple (linear penalties);
  it doesn't account for interaction effects between parameters (e.g. how
  wind changes perceived temperature).
- `cities.json` must contain valid OpenWeatherMap city IDs; there's no
  fallback if a city ID is invalid or the OpenWeatherMap API is
  unreachable beyond the cache serving stale data.
- MFA enrollment currently relies on Auth0's default OTP flow; there's no
  custom UI guiding first-time users through enrollment.

---

## Bonus Features Implemented

- **Dark mode** - class-based, toggled via Tailwind `dark:` variants, persisted in `localStorage`.
- **Sorting/filtering** - sort by rank, score, temperature, or name (ascending/descending); filter by city name search and a minimum-score slider.
- **Unit tests** - cover ideal conditions (score = 100), extreme heat, and clamp boundaries.
