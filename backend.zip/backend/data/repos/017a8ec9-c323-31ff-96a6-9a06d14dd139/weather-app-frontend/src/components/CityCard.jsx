function scoreColor(score) {
  if (score >= 75)
    return "text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800";
  if (score >= 50)
    return "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800";
  return "text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800";
}

function rankBadge(rank) {
  if (rank === 1) return "bg-yellow-400 text-yellow-900 dark:bg-yellow-500 dark:text-yellow-950";
  if (rank === 2) return "bg-gray-300 text-gray-800 dark:bg-gray-400 dark:text-gray-900";
  if (rank === 3) return "bg-amber-600 text-amber-50 dark:bg-amber-700 dark:text-amber-50";
  return "bg-slate-100 text-slate-500 dark:bg-slate-700 dark:text-slate-300";
}

export default function CityCard({ city }) {
  return (
    <div className="relative bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-md dark:hover:shadow-slate-900/50 transition-shadow p-5 flex flex-col gap-3">
      <div
        className={`absolute -top-3 -left-3 w-9 h-9 rounded-full flex items-center justify-center font-semibold text-sm ${rankBadge(
          city.rank
        )}`}
      >
        {city.rank}
      </div>

      <div className="flex items-start justify-between pl-4">
        <div>
          <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100">{city.cityName}</h3>
          <p className="text-sm text-slate-500 dark:text-slate-400 capitalize">{city.weatherDescription}</p>
        </div>
        <div
          className={`px-3 py-1 rounded-full border text-sm font-semibold ${scoreColor(
            city.comfortScore
          )}`}
        >
          {city.comfortScore.toFixed(1)}
        </div>
      </div>

      <div className="grid grid-cols-4 gap-2 pt-2 border-t border-slate-100 dark:border-slate-700 text-center">
        <Metric label="Temp" value={`${city.temperatureCelsius.toFixed(1)}°C`} />
        <Metric label="Humidity" value={`${city.humidity}%`} />
        <Metric label="Wind" value={`${city.windSpeed.toFixed(1)} m/s`} />
        <Metric label="Clouds" value={`${city.cloudiness}%`} />
        <Metric label="Pressure" value={`${city.pressure}HPa`} />
      </div>
    </div>
  );
}

function Metric({ label, value }) {
  return (
    <div>
      <p className="text-xs uppercase tracking-wide text-slate-400 dark:text-slate-500">{label}</p>
      <p className="text-sm font-medium text-slate-700 dark:text-slate-200">{value}</p>
    </div>
  );
}