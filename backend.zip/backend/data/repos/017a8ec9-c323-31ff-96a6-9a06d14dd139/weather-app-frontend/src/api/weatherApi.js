const API_BASE_URL = "http://localhost:8080";


async function apiFetch(path, accessToken) {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });

  if (!response.ok) {
    throw new Error(`Request to ${path} failed with status ${response.status}`);
  }

  return response.json();
}

export function getComfortRankings(accessToken) {
  return apiFetch("/api/comfort-rankings", accessToken);
}

export function getCacheStatus(accessToken) {
  return apiFetch("/api/cache/status", accessToken);
}
